import { Router } from 'express';

export default ({ config }) => {
	let routes = Router();

	// add middleware here

	return routes;
}
